public interface Displayable {
    String[] toStringArray();   
}
